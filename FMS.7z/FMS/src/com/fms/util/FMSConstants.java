package com.fms.util;

public class FMSConstants {

	public static final int AVAILABLE_COMPLETELY = 2;
	public static final int AVAILABLE_PARTIALLY = 1;
	public static final int NOT_AVAILABLE = 0;
	
}
